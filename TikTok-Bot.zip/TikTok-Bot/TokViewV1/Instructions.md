# TokView V1

- Run ```setup.bat``` to install the reqired libraries
- To run the python file do ```python3 TokViewV1.py```

